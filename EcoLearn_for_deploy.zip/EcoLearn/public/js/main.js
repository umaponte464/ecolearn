// Obtener módulos desde el backend
fetch('http://localhost:3000/api/modules')
    .then(response => response.json())
    .then(data => {
        const moduleList = document.getElementById('module-list');
        data.forEach(module => {
            const listItem = document.createElement('li');
            listItem.textContent = module.name;
            moduleList.appendChild(listItem);
        });
    })
    .catch(error => console.error('Error al obtener los módulos:', error));
