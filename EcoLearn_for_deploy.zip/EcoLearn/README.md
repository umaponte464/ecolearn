# EcoLearn

## Descripción
EcoLearn es una plataforma educativa interactiva para aprender sobre prácticas sostenibles.

## Cómo usar
1. Instala Node.js desde [Node.js](https://nodejs.org/).
2. Abre una terminal en la carpeta del proyecto y ejecuta:
   ```bash
   npm install express cors
   ```
3. Inicia el servidor:
   ```bash
   node server/app.js
   ```
4. Abre tu navegador y ve a `http://localhost:3000`.

## Estructura del Proyecto
```
EcoLearn/
├── public/
│   ├── index.html
│   ├── css/styles.css
│   ├── js/main.js
├── server/
│   ├── app.js
├── README.md
```
