const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // Servir archivos del frontend

// Rutas
app.get('/api/modules', (req, res) => {
    res.json([
        { id: 1, name: "Cuidado del Agua" },
        { id: 2, name: "Reciclaje" },
        { id: 3, name: "Huertos Urbanos" },
    ]);
});

// Iniciar servidor
app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});
